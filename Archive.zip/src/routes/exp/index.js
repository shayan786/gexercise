import React from 'react';
import Exp from './Exp';

export default {

  path: '/exp',

  action() {
    return <Exp />;
  },

};
